Copy @ 2021
<script>
    function submitForm(formName) {
        var x = document.getElementsByName(formName.name);
        x[0].submit(); // Form submission
    }
</script>