<?php
    $con = mysqli_connect("localhost", "root", "", "smymdb");
    //if(!$con)
     //echo "Connection unsuccesful";
    //else
     //echo "Connection succesful";
?>