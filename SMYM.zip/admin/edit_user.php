<?php
include "dbcon.php";
$id=$_GET["id"];
?>