<?php
// Add mySQL math

// $path = str_replace('www', '', getcwd());
// system('"'.$path'mysql\bin\mysqld.exe"');

$username = "root";
$servername = "localhost";
$password = "";
$db = "smymdb";
$connect = mysqli_connect($servername, $username, $password, $db);

?>