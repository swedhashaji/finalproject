<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="veiwport" content="width=device-width,initial-scale=1.0">
        <title></title>
        <style>
            a:link, a:visited {
  background-color: #e7e7e7;
  color: black;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}

a:hover, a:active {
  background-color: #e7e7e7;
}

</style>

    </head>
    <body>
    <a href="indexmain.php" target="_blank">Back to Home</a>
        <h1>Payment Successfully Done!!!</h1>
    </body>
</html>